package listas;

import java.util.ArrayList;
import java.util.List;

public class ListaEncadeada {
	
	No inicio;
	int tamanho;
	
	public ListaEncadeada() {
		this.inicio = null;
		this.tamanho = 0;
	}
	
	public void adicionarInicio(int valor) {
		No novo = new No(valor);
		novo.proximo = inicio;
		inicio = novo;
		tamanho++;
	}
	
	public void imprimir() {
		No aux = inicio;
		while(aux!=null) {
			System.out.print(aux.valor+" ");
			aux = aux.proximo;			
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		ListaEncadeada lista = new ListaEncadeada();
		lista.adicionarInicio(10);
		lista.adicionarInicio(20);
		lista.adicionarInicio(100);
		lista.imprimir();
	}
	
	private class No{
		int valor;
		No proximo;
		No(int valor){
			this.valor = valor;
			this.proximo = null;
		}
	}
}
